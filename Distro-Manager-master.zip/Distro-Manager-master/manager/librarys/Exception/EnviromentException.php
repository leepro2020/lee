<?php

    namespace Librarys\Exception;

    class EnvironmentException extends RuntimeException
    {

    }
