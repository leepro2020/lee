<?php

    namespace Librarys\Http\Exception;
    use Librarys\Exception\RuntimeException;

    class SessionException extends RuntimeException
    {

    }
