<?php

    if (defined('LOADED') == false)
        exit;

    define('ASSET_PARAMETER_THEME_URL',  'theme');
    define('ASSET_PARAMETER_CSS_URL',    'css');
    define('ASSET_PARAMETER_JS_URL',     'js');
    define('ASSET_PARAMETER_JS_DIR_URL', 'dir');
    define('ASSET_PARAMETER_RAND_URL',   'rand');

?>